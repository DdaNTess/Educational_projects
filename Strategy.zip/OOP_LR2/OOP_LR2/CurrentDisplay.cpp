#include <iostream>
#include "CurrentDisplay.h"

CurrentDisplay::CurrentDisplay(void)
{
	pos = 0;
	time = 0;
	speed = 0;
}
CurrentDisplay::~CurrentDisplay(void)
{}

void CurrentDisplay::update(float pos, float time, float speed)
{
	this->pos = pos;
	this->time = time;
	this->speed = speed;

}
void CurrentDisplay::display()
{
	std::cout << "������� " << pos << std::endl;
	std::cout << "����� " << time << std::endl;
	std::cout << "�������� " << speed << std::endl;
}
