#include <iostream>
#include "TrackData.h"

TrackData::TrackData(void)
{
	this->observers = new Observer * [2];
	for (int i = 0; i < 2; i++)
	{
		this->observers[i] = 0;
	}
}
TrackData::~TrackData(void)
{
	delete[]observers;
}
void TrackData::registerObserver(Observer* a)
{
	for (int i = 0; i < 2; i++)
	{
		if (observers[i] == 0)
		{
			observers[i] = a;
			return;
		}

	}
	std::cout << "No positions for Observer " << std::endl;
}
void TrackData::removeObserver(Observer* a)
{
	for (int i = 0; i < 2; i++)
	{
		if (observers[i] == a)
		{
			observers[i] = 0;
			return;
		}

	}
	std::cout << "Observer is not in the list " << std::endl;
}
void TrackData::notifyObserver()
{
	for (int i = 0; i < 2; i++)
	{
		if (observers[i] != 0)
		{
			observers[i]->update(this->pos, this->time, this->speed);

		}

	}
}
void TrackData::setMeasurements(float pos, float time, float speed)
{
	this->pos = pos;
	this->time = time;
	this->speed = speed;
	this->notifyObserver();
}
void TrackData::getMeasurements()
{
	float pos, time, speed;
	std::cout << " ������� = "; 
	std::cin >> pos;
	std::cout << " ����� = "; 
	std::cin >> time;
	std::cout << " �������� = ";
	std::cin >> speed;
	this->setMeasurements(pos, time, speed);
}