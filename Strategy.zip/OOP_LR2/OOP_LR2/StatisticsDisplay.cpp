#include "StatisticsDisplay.h"

StatisticsDisplay::StatisticsDisplay(void)
{
	for (int i = 0; i < 3; i++)
	{
		aposition[i] = 0;
		atime[i] = 0;
		aspeed[i] = 0;
	}
}

StatisticsDisplay::~StatisticsDisplay(void)
{}

void StatisticsDisplay::display()
{
	for (int i = 2; i >= 0; i--)

	{
		std::cout << i + 1 << " ������� �����: " << aposition[i] << std::endl;
	}

	for (int i = 2; i >= 0; i--)
	{
		std::cout << i + 1 << " ����� �����: " << atime[i] << std::endl;
	}

	for (int i = 2; i >= 0; i--)
	{
		std::cout << i + 1 << " �������� �����: " << aspeed[i] << std::endl;
	}
}

void StatisticsDisplay::update(float pos, float speed, float time)
{

	for (int j = 1; j >= 0; j--)
	{
		aposition[j + 1] = aposition[j];
		atime[j + 1] = atime[j];
		aspeed[j + 1] = aspeed[j];
	}
	aposition[0] = pos;
	atime[0] = time;
	aspeed[0] = speed;
}