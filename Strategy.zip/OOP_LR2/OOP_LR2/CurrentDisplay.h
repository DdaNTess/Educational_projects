#pragma once
#include "Observer.h"
#include "DisplayElement.h"
class CurrentDisplay :
	public Observer, public DisplayElement
{
	float pos, speed, time;

public:
	CurrentDisplay(void);
	~CurrentDisplay(void);
	void update(float pos, float time, float speed);
	void display();
};
