#pragma once

class Observer
{
public:
	virtual void update(float, float, float) = 0;
};