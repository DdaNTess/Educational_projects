﻿#include <iostream>
#include <conio.h>
#include "TrackData.h"
#include "CurrentDisplay.h"
#include "StatisticsDisplay.h"

void main()
{
	setlocale(LC_ALL, "Russian");
	TrackData T;
	StatisticsDisplay S;
	CurrentDisplay C;

	T.registerObserver(&S);
	T.registerObserver(&C);

	while (1)
	{
		T.getMeasurements();
		S.display();
		C.display();
	}
}
