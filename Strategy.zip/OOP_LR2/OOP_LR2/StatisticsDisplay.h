#pragma once
#include <iostream>
#include "Observer.h"
#include "DisplayElement.h"
class StatisticsDisplay :
	public Observer, public DisplayElement
{
	float average_position, average_time, average_speed;
	float aposition[3];
	float atime[3];
	float aspeed[3];
public:
	StatisticsDisplay(void);
	~StatisticsDisplay(void);
	void update(float pos, float time, float speed);
	void display();
};
