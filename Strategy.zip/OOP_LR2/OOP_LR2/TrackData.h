#pragma once
#include "Subject.h"
#include "Observer.h"
class TrackData :
	public Subject
{
	float pos, time, speed;
	Observer** observers;
public:
	TrackData(void);
	~TrackData(void);
	void registerObserver(Observer* a);
	void removeObserver(Observer* a);
	void setMeasurements(float pos, float time, float speed);
	void getMeasurements();
	void notifyObserver();
};

