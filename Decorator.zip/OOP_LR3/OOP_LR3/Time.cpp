#include "Time.h"
#include <iostream>

Time::Time(Car* car) 
{
	this->car = car;
}

Time::~Time(void) 
{}

float Time::cost()
{
	return (10 * car->cost());
}

void Time::getDescription() 
{
	car->getDescription();
	std::cout << "10 ���" << std::endl;
}