#include "Volkswagen.h" 
#include <iostream>

Volkswagen::Volkswagen()
{}

Volkswagen::~Volkswagen(void)
{}

float Volkswagen::cost()
{
	return 50;
}
void Volkswagen::getDescription() {
	std::cout << "Volkswagen" << std::endl;
}