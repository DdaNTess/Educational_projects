#include "smart.h" 
#include <iostream>

smart::smart()
{}

smart::~smart(void)
{}

float smart::cost()
{
	return 75;
}
void smart::getDescription() {
	std::cout << "Smart" << std::endl;
}