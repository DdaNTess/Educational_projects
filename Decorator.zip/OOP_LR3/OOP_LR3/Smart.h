#pragma once
#include "Car.h"

class smart :
    public Car
{
public:
    smart();
    ~smart(void);
    float cost();
    void getDescription();
};

