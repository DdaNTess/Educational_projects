#pragma once
#include "Car.h"

class CondimentDecorator :
    public Car
{
public:
    virtual void getDescription() = 0;
};
