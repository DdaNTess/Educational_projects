#pragma once
#include "Car.h"

class BMW :
    public Car
{
public:
    BMW();
    ~BMW(void);
    float cost();
    void getDescription();
};
