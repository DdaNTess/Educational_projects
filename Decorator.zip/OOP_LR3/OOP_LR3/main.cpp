#include "CondimentDecorator.h"
#include "Car.h"
#include "smart.h"
#include "BMW.h"
#include "KIO.h"
#include "Mercedes.h"
#include "Volkswagen.h"
#include "WayBack.h"
#include "Time.h"
#include <iostream>
#include <conio.h>

int main()
{
	setlocale(LC_ALL, "Rus");
	Car* car = new Mercedes();
	car = new Time(car);
	car = new WayBack(car);
	car->getDescription();
	std::cout << car->cost() << " � " << std::endl;
	delete car;
	return 0;
}