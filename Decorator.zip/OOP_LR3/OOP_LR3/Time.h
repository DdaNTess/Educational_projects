#pragma once
#include "CondimentDecorator.h"

class Time :
    public CondimentDecorator
{
    Car* car;
public:
    Time(Car* car);
    ~Time(void);
    float cost();
    void getDescription();
};

