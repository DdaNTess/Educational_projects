#include "KIO.h" 
#include <iostream>

KIO::KIO()
{}

KIO::~KIO(void)
{}

float KIO::cost()
{
	return 60;
}
void KIO::getDescription() {
	std::cout << "KIO" << std::endl;
}