#pragma once
#include "CondimentDecorator.h"

class WayBack :
    public CondimentDecorator
{
    Car* car;
public:
    WayBack(Car* car);
    ~WayBack(void);
    float cost();
    void getDescription();
};

