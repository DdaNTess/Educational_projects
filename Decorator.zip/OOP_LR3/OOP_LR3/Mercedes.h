#pragma once
#include "Car.h"

class Mercedes :
    public Car
{
public:
    Mercedes();
    ~Mercedes(void);
    float cost();
    void getDescription();
};
