#pragma once
#include "Car.h"

class Volkswagen :
    public Car
{
public:
    Volkswagen();
    ~Volkswagen(void);
    float cost();
    void getDescription();
};

