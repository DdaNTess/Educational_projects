#include "BMW.h"
#include <iostream>

BMW::BMW()
{}

BMW::~BMW(void)
{}

float BMW::cost()
{
	return 100;
}
void BMW::getDescription() {
	std::cout << "BMW" << std::endl;
}
