#include "Mercedes.h" 
#include <iostream>

Mercedes::Mercedes()
{}

Mercedes::~Mercedes(void)
{}

float Mercedes::cost()
{
	return 90;
}
void Mercedes::getDescription() {
	std::cout << "Mercedes" << std::endl;
}
