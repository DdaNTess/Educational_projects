#pragma once
#include "Car.h"

class KIO :
    public Car
{
public:
    KIO();
    ~KIO(void);
    float cost();
    void getDescription();
};

