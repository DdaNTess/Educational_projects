#include "WayBack.h"
#include <iostream> 

WayBack::WayBack(Car* car) 
{
	this->car = car;
}

WayBack::~WayBack(void) 
{}

float WayBack::cost()
{
	return (2 * car->cost());
}
void WayBack::getDescription() {
	car->getDescription();
	std::cout << "���� �����" << std::endl;
}