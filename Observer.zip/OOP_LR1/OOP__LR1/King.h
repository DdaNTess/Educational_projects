#pragma once
#include "Character.h"
class King :
    public Character
{
public:
    King(void);
    ~King(void);
    void display();

};