#include "Green.h"

Green::Green()
{}

Green::~Green(void)
{}

void Green::Color()
{
	cout << " Green";
}
