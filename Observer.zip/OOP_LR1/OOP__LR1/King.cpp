#include "King.h"

King::King(void)
{}

King::~King(void)
{}

void King::display()
{
	cout << "King";
}
