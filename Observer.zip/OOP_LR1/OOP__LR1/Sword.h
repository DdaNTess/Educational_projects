#pragma once
#include "WeaponBehavior.h"
class Sword : public WeaponBehavior
{
public:
	Sword();
	~Sword(void);
	void Weapon();
};

