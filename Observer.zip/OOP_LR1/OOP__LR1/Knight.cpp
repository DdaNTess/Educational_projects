#include "Knight.h"

Knight::Knight()
{}

Knight::~Knight(void)
{}

void Knight::display()
{
	cout << "Knight";
}
