#pragma once
#include <iostream>
using namespace std;

class WeaponBehavior
{
public:
	virtual void Weapon() = 0;
};