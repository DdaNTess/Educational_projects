#pragma once
#include "Character.h"
class Troll :
    public Character
{
public:
    Troll();
    ~Troll(void);
    void display();
};
