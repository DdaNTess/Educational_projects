#include "Blue.h"

Blue::Blue()
{}

Blue::~Blue()
{}

void Blue::Color()
{
	cout << " Blue";
}