#pragma once
#include "ColorBehavior.h"
class Yellow :
    public ColorBehavior
{
public:
    Yellow();
    ~Yellow(void);
    void Color();
};

