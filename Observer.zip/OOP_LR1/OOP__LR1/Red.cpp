#include "Red.h"

Red::Red()
{}

Red::~Red(void)
{}

void Red::Color()
{
	cout << " Red";
}
