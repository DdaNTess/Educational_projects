#pragma once
#include "Character.h"
class Queen :
    public Character
{
public:
    Queen();
    ~Queen(void);
    void display();
};

