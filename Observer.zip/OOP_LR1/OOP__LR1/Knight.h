#pragma once
#include "Character.h"
class Knight :
    public Character
{
public:
    Knight();
    ~Knight(void);
    void display();
};

