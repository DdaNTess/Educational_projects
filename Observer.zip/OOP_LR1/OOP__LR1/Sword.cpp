#include "Sword.h"

Sword::Sword()
{}

Sword::~Sword(void)
{}

void Sword::Weapon()
{
	cout << " Sword" << endl;
}
