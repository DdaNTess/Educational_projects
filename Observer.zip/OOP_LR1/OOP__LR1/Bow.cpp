#include "Bow.h"

Bow::Bow()
{}

Bow::~Bow(void)
{}

void Bow::Weapon()
{
	cout << " Bow" << endl;
}
