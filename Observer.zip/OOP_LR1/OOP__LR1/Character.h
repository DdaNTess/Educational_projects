#pragma once
#include <iostream>
#include "WeaponBehavior.h"
#include "ColorBehavior.h"
using namespace std;

class Character
{
	WeaponBehavior* f1;
	ColorBehavior* q1;
public:
	void SetWeaponBehavior(WeaponBehavior* f)
	{
		this->f1 = f;
	}
	void Weapon()
	{
		f1->Weapon();
	}
	void SetColorBehavior(ColorBehavior* q)
	{
		this->q1 = q;
	}
	void Color()
	{
		q1->Color();
	}
	virtual void display() = 0;

};
