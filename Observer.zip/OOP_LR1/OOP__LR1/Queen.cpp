#include "Queen.h"

Queen::Queen()
{}

Queen::~Queen(void)
{}

void Queen::display()
{
	cout << "Queen";
}