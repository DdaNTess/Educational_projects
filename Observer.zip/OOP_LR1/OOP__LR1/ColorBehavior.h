#pragma once
#include <iostream>
using namespace std;

class ColorBehavior
{
public:
	virtual void Color() = 0;
};

