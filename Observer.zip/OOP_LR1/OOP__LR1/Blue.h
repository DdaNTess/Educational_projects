#pragma once
#include "ColorBehavior.h"
class Blue :
    public ColorBehavior
{
public:
    Blue();
    ~Blue(void);
    void Color();
};
