#include "Troll.h"

Troll::Troll()
{}

Troll::~Troll(void)
{}

void Troll::display()
{
	cout << "Troll";
}
