﻿#include <iostream>
#include <conio.h>
#include "King.h"
#include "Queen.h"
#include "Knight.h"
#include "Troll.h"
#include "Sword.h"
#include "Bow.h"
#include "Crossbow.h"
#include "Red.h"
#include "Green.h"
#include "Blue.h"
#include "Yellow.h"
using namespace std;

int main()
{
	setlocale(LC_ALL, "Russian");
	Character** di;
	int a, n, j, k;
	WeaponBehavior* wb_sword, * wb_bow, * wb_crossbow;
	ColorBehavior* cb_blue, * cb_red, * cb_green, * cb_yellow;

	wb_sword = new Sword();
	wb_bow = new Bow();
	wb_crossbow = new Crossbow();
	cb_blue = new Blue();
	cb_red = new Red();
	cb_green = new Green();
	cb_yellow = new Yellow();
	cout << "Выберите два персонажа для борьбы?" << endl;
	a = 2;

	di = new Character * [a];
	for (int i = 0; i < a; i++)
	{
		cout << "Выберите тип персонажа: 1 - King, 2 - Queen, 3 - Knight, 4 - Troll" << endl;
		cin >> n;
		cout << "Тип перосонажа: 1- Sword, 2 - Bow, 3 - Crossbow" << endl;
		cin >> j;
		cout << "Тип цвета: 1 - Blue, 2 - Red, 3 - Green, 4 - Yellow" << endl;
		cin >> k;
		switch (n)
		{
		case 1:
			di[i] = new King();
			break;
		case 2:
			di[i] = new Queen();
			break;
		case 3:
			di[i] = new Knight();
			break;
		case 4:
			di[i] = new Troll();
			break;
		default:
			cout << "Мимо" << endl;
		}
		switch (j)
		{
		case 1:
			di[i]->SetWeaponBehavior(wb_sword);
			break;
		case 2:
			di[i]->SetWeaponBehavior(wb_bow);
			break;
		case 3:
			di[i]->SetWeaponBehavior(wb_crossbow);
			break;
		default:
			cout << "Мимо" << endl;
		}
		switch (k)
		{
		case 1:
			di[i]->SetColorBehavior(cb_blue);
			break;
		case 2:
			di[i]->SetColorBehavior(cb_red);
			break;
		case 3:
			di[i]->SetColorBehavior(cb_green);
			break;
		case 4:
			di[i]->SetColorBehavior(cb_yellow);
			break;
		default:
			cout << "Мимо" << endl;
		}
	}

	for (int i = 0; i < a; i++)
	{
		di[i]->display();
		di[i]->Color();
		di[i]->Weapon();
	}

	for (int i = 0; i < a; i++)
	{
		delete di[i];
	}

	delete[] di;
	delete wb_sword;
	delete wb_bow;
	delete wb_crossbow;
	delete cb_blue;
	delete cb_red;
	delete cb_green;
	delete cb_yellow;
}