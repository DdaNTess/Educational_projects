#pragma once
#include "WeaponBehavior.h"
class Bow : public WeaponBehavior
{
public:
	Bow();
	~Bow(void);
	void Weapon();
};
