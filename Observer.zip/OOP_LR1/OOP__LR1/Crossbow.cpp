#include "Crossbow.h"

Crossbow::Crossbow()
{}

Crossbow::~Crossbow()
{}

void Crossbow::Weapon()
{
	cout << " Crossbow" << endl;
}