#pragma once
#include "ColorBehavior.h"
class Red :public ColorBehavior
{
public:
	Red();
	~Red(void);
	void Color();
};
