#pragma once
#include "WeaponBehavior.h"
class Crossbow :
    public WeaponBehavior
{
public:
    Crossbow();
    ~Crossbow(void);
    void Weapon();
};
