#pragma once
#include "ColorBehavior.h"
class Green : public ColorBehavior
{
public:
	Green();
	~Green(void);
	void Color();
};


