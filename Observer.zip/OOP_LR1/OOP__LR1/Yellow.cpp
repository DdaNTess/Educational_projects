#include "Yellow.h"

Yellow::Yellow()
{}

Yellow::~Yellow()
{}

void Yellow::Color()
{
	cout << " Yellow";
}
